package com.example.childquizunlock

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.LocalDateTime

object Scheduler {
    fun scheduleNext(c: Context) {
        val parts = State.lockTime(c).split(":")
        val hour = parts.getOrNull(0)?.toIntOrNull()?.coerceIn(0,23) ?: 21
        val minute = parts.getOrNull(1)?.toIntOrNull()?.coerceIn(0,59) ?: 30
        var next = LocalDateTime.now().withHour(hour).withMinute(minute).withSecond(0).withNano(0)
        if (!next.isAfter(LocalDateTime.now())) next = next.plusDays(1)
        val intent = Intent(c, AlarmReceiver::class.java)
        val pi = PendingIntent.getBroadcast(c, 1001, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val millis = next.atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
        }
    }
    fun cancel(c: Context) {
        val pi = PendingIntent.getBroadcast(c, 1001, Intent(c, AlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
    }
}
