package com.example.childquizunlock

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import java.time.LocalTime
import java.time.LocalDate
import kotlin.random.Random

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private var current: Question? = null
    private var parentMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        reconcile()
        showHome()
        Scheduler.scheduleNext(this)
    }

    override fun onResume() {
        super.onResume()
        reconcile()
        if (State.isLocked(this)) showQuiz()
    }

    private fun reconcile() {
        if (!State.isUnlockedToday(this)) {
            val p = State.lockTime(this).split(":")
            val t = LocalTime.of(p[0].toInt(), p[1].toInt())
            if (!LocalTime.now().isBefore(t)) State.beginLock(this)
        }
        applyKioskIfOwner()
    }

    private fun applyKioskIfOwner() {
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        if (dpm.isDeviceOwnerApp(packageName)) {
            try {
                dpm.setLockTaskPackages(ComponentName(this, AdminReceiver::class.java), arrayOf(packageName))
                if (State.isLocked(this)) startLockTask()
                else stopLockTask()
            } catch (_: Exception) {}
        }
    }

    private fun base(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 36, 36, 36)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val heading = TextView(this).apply {
            text = title; textSize = 26f; gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        root.addView(heading)
        setContentView(root)
    }
    private fun text(s: String, size: Float = 18f) {
        root.addView(TextView(this).apply {
            text = s; textSize = size; gravity = Gravity.CENTER
            setPadding(8, 12, 8, 12)
        })
    }
    private fun button(label: String, action: () -> Unit): Button {
        val b = Button(this).apply { text = label; setOnClickListener { action() } }
        root.addView(b)
        return b
    }
    private fun field(hint: String, value: String = ""): EditText {
        val e = EditText(this).apply { this.hint = hint; setText(value) }
        root.addView(e); return e
    }
    private fun showHome() {
        if (State.isLocked(this)) { showQuiz(); return }
        base("小管家 · 儿童答题解锁")
        text("每日锁定时间：${State.lockTime(this)}")
        text("连续答对 ${State.target(this)} 道题后解锁")
        text("今日状态：${if (State.isUnlockedToday(this)) "已解锁" else "正常使用"}")
        button("家长管理（长按进入）") { showParentLogin() }.setOnLongClickListener {
            showParentLogin(); true
        }
        button("检查设备管控状态") {
            val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val owner = dpm.isDeviceOwnerApp(packageName)
            Toast.makeText(this, if (owner) "已注册设备所有者" else "尚未注册设备所有者", Toast.LENGTH_LONG).show()
        }
    }
    private fun showQuiz() {
        base("学习挑战")
        val qs = State.questions(this)
        if (qs.isEmpty()) { text("题库为空，请联系家长"); return }
        current = qs.random()
        text("连续答对：${State.streak(this)} / ${State.target(this)}", 20f)
        text(current!!.prompt, 26f)
        val answer = field("请输入答案")
        button("提交答案") {
            val q = current ?: return@button
            val ok = normalize(answer.text.toString()) == normalize(q.answer)
            if (ok) {
                val n = State.streak(this) + 1
                State.setStreak(this, n)
                State.record(this, "${System.currentTimeMillis()}|${q.prompt}|正确|$n")
                if (n >= State.target(this)) {
                    State.markUnlockedToday(this)
                    stopKioskIfOwner()
                    Toast.makeText(this, "答题通过，今天已解锁", Toast.LENGTH_LONG).show()
                    showHome()
                } else showQuiz()
            } else {
                State.setStreak(this, 0)
                State.record(this, "${System.currentTimeMillis()}|${q.prompt}|错误|0")
                Toast.makeText(this, "回答错误，连续答题重新计数", Toast.LENGTH_SHORT).show()
                showQuiz()
            }
        }
        text("答错后连续正确数量归零")
        button("家长紧急解锁") { showParentLogin() }
    }
    private fun normalize(s: String) = s.trim().replace(" ", "").lowercase()
    private fun stopKioskIfOwner() {
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        if (dpm.isDeviceOwnerApp(packageName)) try { stopLockTask() } catch (_: Exception) {}
    }
    private fun showParentLogin() {
        base("家长验证")
        val pin = field("请输入家长 PIN")
        button("验证") {
            if (pin.text.toString() == State.pin(this)) showParent()
            else Toast.makeText(this, "PIN 不正确", Toast.LENGTH_SHORT).show()
        }
    }
    private fun showParent() {
        parentMode = true
        base("家长管理")
        val time = field("锁定时间 HH:mm", State.lockTime(this))
        val target = field("连续答对数量", State.target(this).toString())
        val pin = field("新管理员 PIN（至少 6 位）", State.pin(this))
        button("保存设置") {
            val parts = time.text.toString().split(":")
            val hour = parts.getOrNull(0)?.toIntOrNull()
            val minute = parts.getOrNull(1)?.toIntOrNull()
            val validTime = parts.size == 2 && hour != null && minute != null && hour in 0..23 && minute in 0..59
            val n = target.text.toString().toIntOrNull()
            if (!validTime || n == null || n !in 1..50 || pin.text.length < 6) {
                Toast.makeText(this, "请检查时间、题数和至少 6 位 PIN", Toast.LENGTH_LONG).show()
            } else {
                State.saveSettings(this, time.text.toString(), n, pin.text.toString())
                Scheduler.cancel(this); Scheduler.scheduleNext(this)
                Toast.makeText(this, "设置已保存", Toast.LENGTH_SHORT).show()
                showParent()
            }
        }
        button("编辑题库（每行：题目|答案）") { showQuestionEditor() }
        button("查看答题记录") { base("答题记录"); text(State.logs(this), 13f); button("返回") { showParent() } }
        button("手动锁定测试") { State.beginLock(this); showQuiz() }
        button("紧急解除并标记今日已解锁") {
            State.markUnlockedToday(this); stopKioskIfOwner(); showHome()
        }
        button("返回") { showHome() }
    }
    private fun showQuestionEditor() {
        base("题库编辑")
        val content = State.questions(this).joinToString("\n") { "${it.prompt}|${it.answer}" }
        val editor = EditText(this).apply {
            setText(content); minLines = 8; gravity = Gravity.TOP
            hint = "每行一题，格式：题目|答案"
        }
        root.addView(editor, LinearLayout.LayoutParams(-1, 0, 1f))
        button("保存题库") {
            val qs = editor.text.lines().mapNotNull {
                val a = it.split("|", limit = 2)
                if (a.size == 2 && a[0].isNotBlank() && a[1].isNotBlank()) Question(a[0].trim(), a[1].trim()) else null
            }
            if (qs.isEmpty()) Toast.makeText(this, "至少需要一道有效题目", Toast.LENGTH_SHORT).show()
            else { State.saveQuestions(this, qs); Toast.makeText(this, "已保存 ${qs.size} 道题", Toast.LENGTH_SHORT).show(); showParent() }
        }
        button("返回") { showParent() }
    }
}
