package com.example.childquizunlock

import android.content.Context
import java.time.LocalDate

object State {
    private const val PREF = "child_quiz_state"
    private fun p(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun lockTime(c: Context): String = p(c).getString("lock_time", "21:30") ?: "21:30"
    fun target(c: Context): Int = p(c).getInt("target", 5).coerceIn(1, 50)
    fun pin(c: Context): String = p(c).getString("parent_pin", "246810") ?: "246810"
    fun isLocked(c: Context) = p(c).getBoolean("locked", false)
    fun setLocked(c: Context, value: Boolean) { p(c).edit().putBoolean("locked", value).apply() }
    fun streak(c: Context) = p(c).getInt("streak", 0)
    fun setStreak(c: Context, value: Int) { p(c).edit().putInt("streak", value).apply() }
    fun unlockedDate(c: Context): String? = p(c).getString("unlocked_date", null)
    fun isUnlockedToday(c: Context) = unlockedDate(c) == LocalDate.now().toString()
    fun markUnlockedToday(c: Context) {
        p(c).edit().putString("unlocked_date", LocalDate.now().toString())
            .putBoolean("locked", false).putInt("streak", target(c)).apply()
    }
    fun beginLock(c: Context) {
        p(c).edit().putBoolean("locked", true).putInt("streak", 0).apply()
    }
    fun saveSettings(c: Context, time: String, target: Int, pin: String) {
        p(c).edit().putString("lock_time", time).putInt("target", target.coerceIn(1, 50))
            .putString("parent_pin", pin).apply()
    }
    fun questions(c: Context): List<Question> {
        val raw = p(c).getString("questions", null)
        if (raw.isNullOrBlank()) return listOf(
            Question("25 × 16 = ?", "400"),
            Question("太阳从哪个方向升起？", "东方"),
            Question("Apple 的中文是什么？", "苹果"),
            Question("9 × 8 = ?", "72"),
            Question("一年有几个月？", "12")
        )
        return raw.split("\n").mapNotNull {
            val parts = it.split("|", limit = 2)
            if (parts.size == 2 && parts[0].isNotBlank()) Question(parts[0], parts[1]) else null
        }.ifEmpty { listOf(Question("题库为空，请联系家长", "无")) }
    }
    fun saveQuestions(c: Context, qs: List<Question>) {
        p(c).edit().putString("questions", qs.joinToString("\n") { "${it.prompt}|${it.answer}" }).apply()
    }
    fun record(c: Context, line: String) {
        val old = p(c).getString("logs", "") ?: ""
        p(c).edit().putString("logs", (old + "\n" + line).takeLast(12000)).apply()
    }
    fun logs(c: Context) = p(c).getString("logs", "") ?: ""
}
data class Question(val prompt: String, val answer: String)
