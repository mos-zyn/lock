package com.example.childquizunlock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.time.LocalTime

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        Scheduler.scheduleNext(context)
        val parts = State.lockTime(context).split(":")
        val lockAt = LocalTime.of(
            parts.getOrNull(0)?.toIntOrNull()?.coerceIn(0,23) ?: 21,
            parts.getOrNull(1)?.toIntOrNull()?.coerceIn(0,59) ?: 30
        )
        if (!State.isUnlockedToday(context) && LocalTime.now().isAfter(lockAt)) {
            State.beginLock(context)
        }
    }
}
