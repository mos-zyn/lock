package com.example.childquizunlock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (!State.isUnlockedToday(context)) {
            State.beginLock(context)
            val launch = Intent(context, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("show_quiz", true)
            }
            try { context.startActivity(launch) } catch (_: Exception) {
                // Android/MagicOS may block background activity launch; BootReceiver/launcher
                // reconciliation will enforce the pending lock when the app next becomes visible.
            }
        }
        Scheduler.scheduleNext(context)
    }
}
