package com.example.childquizunlock

import android.app.admin.DeviceAdminReceiver

class AdminReceiver : DeviceAdminReceiver()
